#include "DBManager.h"
#include "AsyncLogger.h"

DBManager& DBManager::GetInstance() {
    static DBManager instance;
    return instance;
}

DBManager::DBManager() {}

DBManager::~DBManager() {
    // [Ŀ�ؼ� Ǯ ��ü ����]
    for (auto conn : m_connectionPool) {
        delete conn;
    }
    m_connectionPool.clear();
}

void DBManager::Init(const std::string& host, const std::string& user,
    const std::string& password, const std::string& schema) {
    try {
        m_driver = sql::mysql::get_mysql_driver_instance();

        // [CONNECTION_POOL_SIZE��ŭ ���� ����]
        for (int i = 0; i < CONNECTION_POOL_SIZE; ++i) {
            sql::Connection* conn = m_driver->connect(host, user, password);
            conn->setSchema(schema);
            m_connectionPool.push_back(conn);
        }
        AsyncLogger::GetInstance().Log("DBManager �ʱ�ȭ �Ϸ�");
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "MySQL �ʱ�ȭ ����: " + std::string(e.what()));
    }
}

sql::Connection* DBManager::GetConnection() {
    std::lock_guard<std::mutex> lock(m_poolLock);
    if (!m_connectionPool.empty()) {
        sql::Connection* conn = m_connectionPool.back();
        m_connectionPool.pop_back();
        return conn;
    }
    AsyncLogger::GetInstance().LogError("DBManager Ŀ�ؼ� Ǯ�� ��� �ֽ��ϴ�.");
    return nullptr;
}

void DBManager::ReturnConnection(sql::Connection* conn) {
    std::lock_guard<std::mutex> lock(m_poolLock);
    m_connectionPool.push_back(conn);
}

bool DBManager::InsertCharacter(const PKT_Character& pkt) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: ĳ���� ���� ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "ĳ���� ���� ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::UpdateCharacterStat(const PKT_CharacterStat& pkt) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: ĳ���� ���� ���� ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "ĳ���� ���� ���� ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::SelectCharacter(uint64_t characterId, PKT_Character& outPkt) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: ĳ���� ��ȸ ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "ĳ���� ��ȸ ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::InsertInventory(const PKT_Inventory& pkt) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: �κ��丮 ���� ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "�κ��丮 ���� ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::SelectInventory(uint64_t characterId, std::vector<PKT_Inventory>& outList) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: �κ��丮 ��ȸ ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "�κ��丮 ��ȸ ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::InsertAuction(const PKT_Auction& pkt) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: �ŷ��� ��� ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "�ŷ��� ��� ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::UpdateAuctionStatus(uint64_t auctionId, TradeStatus status) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: �ŷ��� ���� ���� ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "�ŷ��� ���� ���� ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}

bool DBManager::SelectAuction(uint64_t auctionId, PKT_Auction& outPkt) {
    sql::Connection* conn = GetConnection();
    if (!conn) return false;
    try {
        // TODO: �ŷ��� ��ȸ ����
        ReturnConnection(conn);
        return true;
    }
    catch (sql::SQLException& e) {
        AsyncLogger::GetInstance().LogError(
            "�ŷ��� ��ȸ ����: " + std::string(e.what()));
        ReturnConnection(conn);
        return false;
    }
}